CS6210: Final Project - License Plate Detection Program
Elana Lapins


1. Unzip and load all data in "FinalProject_ElanaLapins.zip" into MATLAB directory. 
2. Open "MAIN_ElanaLapins.m" and Run


MAIN: "MAIN_ElanaLapins.m"
IMAGE DATA: "plate images" folder
TRAINING IMAGES: (Nishant Kumar (2022). License plate recognition (https://www.mathworks.com/matlabcentral/fileexchange/54456-licence-plate-recognition), MATLAB Central File Exchange.)
Training Image MATRIX (created separately): "trainingdata.mat"